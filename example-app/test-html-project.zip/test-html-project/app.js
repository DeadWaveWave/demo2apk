const logEl = document.getElementById('log');
const btn = document.getElementById('btn');

function log(msg) {
  const time = new Date().toLocaleTimeString();
  logEl.textContent += `[${time}] ${msg}\n`;
}

btn.addEventListener('click', () => {
  log('Button clicked — JS is working!');
});

log('JS loaded. Click the button to test.');
